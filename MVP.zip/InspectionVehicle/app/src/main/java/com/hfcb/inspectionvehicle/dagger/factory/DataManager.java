package com.hfcb.inspectionvehicle.dagger.factory;

import java.util.concurrent.TimeUnit;

import javax.inject.Inject;
import javax.inject.Singleton;

import io.reactivex.Observable;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

@Singleton
public class DataManager implements ApiInterface {
    private static ApiInterface SERVICE;
    private static final int DEFAULT_TIMEOUT = 10;

    @Inject
    DataManager() {
    }

    public static ApiInterface getDefault() {
        if (SERVICE == null) {
            // 创建OkHttpClient 设置超时时间
            OkHttpClient.Builder httpClientBuilder = new OkHttpClient.Builder();
            httpClientBuilder.connectTimeout(DEFAULT_TIMEOUT, TimeUnit.SECONDS);
            httpClientBuilder.readTimeout(DEFAULT_TIMEOUT, TimeUnit.SECONDS);
            httpClientBuilder.writeTimeout(DEFAULT_TIMEOUT, TimeUnit.SECONDS);

            // HTTPS
//            CustomTrust ct = new CustomTrust();
//            httpClientBuilder.sslSocketFactory(ct.sslSocketFactory, ct.trustManager);
//            httpClientBuilder.hostnameVerifier((hostname, session) -> true);

            // 拦截器
            httpClientBuilder.addInterceptor(chain -> {
                Request request = chain.request();

                HttpUrl.Builder authorizedUrlBuilder = request.url()
                        .newBuilder();
                Request newRequest = request.newBuilder()
//                        .header("Authorization", "Basic YW5kcm9pZDphbmRyb2lk")
                        .method(request.method(), request.body())
                        .url(authorizedUrlBuilder.build())
                        .build();

                return chain.proceed(newRequest);
            });


            SERVICE = new Retrofit.Builder()
                    .client(httpClientBuilder.build())
                    .addConverterFactory(GsonConverterFactory.create())
                    .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                    .baseUrl("")
                    .build().create(ApiInterface.class);
        }
        return SERVICE;
    }

    @Override
    public Observable<Void> inspection(String accessToken, RequestBody body) {
        return getDefault().inspection(accessToken, body);
    }

    public String toast(){
       return "~~~";
    }
}
