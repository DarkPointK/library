package com.hfcb.inspectionvehicle.dagger.module;

import android.app.Application;
import android.content.Context;

import com.hfcb.inspectionvehicle.dagger.ApplicationContext;

import dagger.Module;
import dagger.Provides;

@Module
public class ApplicationModule {
    private Application mApplication;

    public ApplicationModule(Application application) {
        mApplication = application;
    }

    @Provides
    @ApplicationContext
    Context provideContext() {
        return mApplication;
    }

    @Provides
    Application provideApplication() {
        return mApplication;
    }

//    @Provides
//    @Singleton
//    DataManager provideDataManager(DataManager dataManager){
//        return dataManager;
//    }
}
