package com.hfcb.inspectionvehicle.utils;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.YuvImage;
import android.hardware.Camera;
import android.os.Environment;
import android.support.media.ExifInterface;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.Base64;


import com.hfcb.inspectionvehicle.MyApplication;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;


/**
 * 对照片进行相应处理
 */
public class PhotoUtils {

    public static final String JPEG_FILE_SUFFIX = ".jpg";

    public static final String PHOTO_TYPE_START_PARKING = "hfcb";//停车

    /**
     * 压缩并保存图片
     *
     * @param rawBitmap 要保存的图片
     * @param mFilePath 保存的路径
     * @param quality   保存的质量
     */
    public static void compressAndSaveBitmap(Bitmap rawBitmap, String mFilePath, int quality) {
        if (rawBitmap == null)
            return;

        File saveFile = new File(mFilePath);
        if (saveFile.exists()) {
            saveFile.delete();
        }
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(saveFile);

            rawBitmap = compressImage(rawBitmap);
            rawBitmap.compress(Bitmap.CompressFormat.JPEG, quality,
                    fileOutputStream);
            fileOutputStream.flush();
            fileOutputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (!rawBitmap.isRecycled()) {
                rawBitmap.recycle();
            }
        }
    }

    public static void saveBitmap(Bitmap bitmap, String mFilePath, int quality) {
        if (bitmap == null)
            return;

        File saveFile = new File(mFilePath);
        if (saveFile.exists()) {
            saveFile.delete();
        }
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(saveFile);
            bitmap.compress(Bitmap.CompressFormat.JPEG, quality, fileOutputStream);
            fileOutputStream.flush();
            fileOutputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (!bitmap.isRecycled()) {
                bitmap.recycle();
            }
        }
    }

    /**
     * 压缩图片
     *
     * @param image
     * @return
     */
    private static Bitmap compressImage(Bitmap image) {
        boolean twice = false;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        int options = 90;
        image.compress(Bitmap.CompressFormat.JPEG, options, baos);//质量压缩方法，这里100表示不压缩，把压缩后的数据存放到baos中
        while (baos.toByteArray().length / 1024 > 80) {  //循环判断如果压缩后图片是否大于80kb,大于继续压缩
            baos.reset();//重置baos即清空baos
            if (options > 10) {
                options -= 10;//每次都减少10
            } else {
                image.compress(Bitmap.CompressFormat.JPEG, options,
                        baos);//这里压缩options%，把压缩后的数据存放到baos中
                break;
            }
            image.compress(Bitmap.CompressFormat.JPEG, options,
                    baos);//这里压缩options%，把压缩后的数据存放到baos中
        }
        ByteArrayInputStream isBm = new ByteArrayInputStream(
                baos.toByteArray());//把压缩后的数据baos存放到ByteArrayInputStream中
        return BitmapFactory.decodeStream(isBm, null, null);
    }

    /**
     * 将data转为bitmap 并且设置角度
     */
    public static Bitmap getBitmap(byte[] data, Camera camera) {
        if (camera == null)
            return null;

        Camera.Parameters parameters = camera.getParameters();
        int imageFormat = parameters.getPreviewFormat();
        int w = parameters.getPreviewSize().width;
        int h = parameters.getPreviewSize().height;
        Rect rect = new Rect(0, 0, w, h);
        YuvImage yuvImg = new YuvImage(data, imageFormat, w, h, null);
        Bitmap bitmap = null;
        try {
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            yuvImg.compressToJpeg(rect, 100, outputStream);
            bitmap = BitmapFactory.decodeByteArray(outputStream.toByteArray(), 0, outputStream.size());
            // Rotate the Bitmap
            Matrix matrix = new Matrix();
            matrix.postRotate(90);

            // We rotate the same Bitmap
            bitmap = Bitmap.createBitmap(bitmap, 0, 0, w, h, matrix, false);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return bitmap;
    }


    /**
     * 添加水印 - 违章（时间、地址）
     *
     * @param bitmap 图片
     * @return 添加水印后的图片
     */
    public static Bitmap addWaterMarkForIllegal(Bitmap bitmap, String time, String address) {

        int w = bitmap.getWidth();
        int h = bitmap.getHeight();
        Bitmap.Config config = Bitmap.Config.ARGB_8888;
        Bitmap bmpTemp;
        try {
            bmpTemp = Bitmap.createBitmap(w, h, config);
        } catch (OutOfMemoryError e) {
            e.printStackTrace();
            return null;
        }

        if (bmpTemp == null)
            return null;

        Canvas canvas = new Canvas(bmpTemp);
        Paint p = new Paint();
        String fontName = "serif";
        int ts = w > h ? w : h;
        int textSize = ts / 30;
        Typeface font = Typeface.create(fontName, Typeface.NORMAL);
        p.setColor(Color.RED);
        p.setTypeface(font);
        p.setTextSize(textSize);
        canvas.drawBitmap(bitmap, 0, 0, p);
        canvas.drawText(time, 20, textSize, p);

        //添加地址水印
        if (!TextUtils.isEmpty(address)) {
            if (address.length() > 20) {
                canvas.drawText(address.substring(0, 20), 20, textSize * 2 + 20, p);
                canvas.drawText(address.substring(20, address.length()), 20, textSize * 3 + 30, p);
            } else {
                canvas.drawText(address, 20, textSize * 2 + 20, p);
            }
        } else {
            canvas.drawText("暂无位置信息", 20, textSize * 2 + 20, p);
        }

        canvas.save(Canvas.ALL_SAVE_FLAG);
        canvas.restore();
        if (!bitmap.isRecycled()) {
            bitmap.recycle();
        }
        return bmpTemp;
    }

    /**
     * 获取车辆驶入时拍照图片保存路径
     */
    public static String getPhotoPath(Context context) {
        String lPath;
        if (Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState())) {
            lPath = Environment.getExternalStorageDirectory().getPath().concat("/DCIM/");
        } else {
            lPath = context.getCacheDir().getPath().concat("/");
        }
        return lPath.concat(PHOTO_TYPE_START_PARKING).concat("/");
    }

    /**
     * Bitmap --》 字节 --》 Base64字符串
     *
     * @param bit
     * @return
     */
    public static String Bitmap2StrByBase64(Bitmap bit, int quality) {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        //参数100表示不压缩
        bit.compress(Bitmap.CompressFormat.JPEG, quality, bos);
        byte[] bytes = bos.toByteArray();
        return Base64.encodeToString(bytes, Base64.DEFAULT);
    }


    /**
     * 旋转 并且 缩放图片 如果是竖着拍的 返回null
     *
     * @param imagePath
     * @return
     */
    public static Bitmap rotateAndCompressPic(String imagePath, int scalePx, boolean isJudgeOrientation) {
        Bitmap bitmap = null;
        int degree = 0;
        try {
            ExifInterface exifInterface = new ExifInterface(imagePath);
            int orientation =
                    exifInterface.getAttributeInt(ExifInterface.TAG_ORIENTATION,
                            ExifInterface.ORIENTATION_NORMAL);
            switch (orientation) {
                case ExifInterface.ORIENTATION_ROTATE_90:
                    degree = 90;
                    break;
                case ExifInterface.ORIENTATION_ROTATE_180:
                    degree = 180;
                    break;
                case ExifInterface.ORIENTATION_ROTATE_270:
                    degree = 270;
                    break;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            BitmapFactory.Options opts = new BitmapFactory.Options();
            // 如果设置为true,仅仅返回图片的宽和高,宽和高是赋值给opts.outWidth,opts.outHeight;
            opts.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(imagePath, opts);
            // 得到原图的宽和高
            int srcWidth = opts.outWidth;
            int srHeigth = opts.outHeight;

            if (isJudgeOrientation) {
                if (srcWidth < srHeigth) {
                    return null;
                }
            }

            //获取缩放的比例(我这里设置的是80dp)
            int scale = 1;
            int sx = srcWidth / scalePx;
            int sy = srHeigth / scalePx;

            // 取一个大的
            if (sx > sy && sx > 1) {
                scale = sx;
            }
            if (sy > sx && sy > 1) {
                scale = sy;
            }

            // 设置为false表示,让decodeFile返回一个bitmap类型的对象
            opts.inJustDecodeBounds = false;
            // 设置缩放的比例,设置后,decodeFile方法就会按照这个比例缩放图片,加载到内存
            opts.inSampleSize = scale;
            // 缩放图片加载到内存(一般加载图片到内存，都要根据手机屏幕宽高对图片进行适当缩放，否则可能出现OOM异常)
            bitmap = BitmapFactory.decodeFile(imagePath, opts);

            if (degree == 0 || null == bitmap) {
                return bitmap;
            }
            Matrix matrix = new Matrix();
            matrix.setRotate(degree, bitmap.getWidth() / 2, bitmap.getHeight() / 2);
            Bitmap bmp = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);

            if (null != bitmap && bitmap.isRecycled()) {
                bitmap.recycle();
                bitmap = null;
            }
            return bmp;

        } catch (Exception e) {
            return null;
        }
    }


    /**
     * 添加水印 重新保存
     *
     * @param path    图片路径
     * @param time    水印 - 时间
     * @param address 水印 - 地址
     * @return 有水印的图片的路径
     */
    public static String getNewPath(String path, String time, String address) {
        if (TextUtils.isEmpty(path)) {
            return "";
        }

        Bitmap bitmap = BitmapFactory.decodeFile(path);
        if (bitmap == null) {
            return "";
        }
        // 加水印后保存的地址
        String picPath = getPhotoPath(MyApplication.getInstance());
        String picName = TimeUtils.getNowString(TimeUtils.FORMAT_NEAT).concat("_").concat(PHOTO_TYPE_START_PARKING).concat("_mark").concat(JPEG_FILE_SUFFIX);

        // 保存bitmap
        String pathCompress = picPath.concat(picName);
        compressAndSaveBitmap(addWaterMark(bitmap, time, address), pathCompress, 100);
        return pathCompress;
    }

    /**
     * 添加水印（时间、地址）
     *
     * @param bitmap 图片
     * @return 添加水印后的图片
     */
    private static Bitmap addWaterMark(Bitmap bitmap, String time, String address) {

        String markText = time + "\r\n" + address;

        int w = bitmap.getWidth();
        int h = bitmap.getHeight();
        Bitmap.Config config = Bitmap.Config.ARGB_8888;
        Bitmap bmpTemp;
        try {
            bmpTemp = Bitmap.createBitmap(w, h, config);
        } catch (OutOfMemoryError e) {
            e.printStackTrace();
            return null;
        }

        if (bmpTemp == null)
            return null;

        Canvas canvas = new Canvas(bmpTemp);

        // 画背景图
        canvas.drawBitmap(bitmap, 0, 0, null);

        if (!TextUtils.isEmpty(address)) {
            int screenWidth = Utils.getScreenWidth();

            int ts = w > h ? w : h;
            int textSize = ts / 30;
//            float textSize = dp2px(App.getInstance(), 16) * w / screenWidth;

            // 创建画笔
            TextPaint mPaint = new TextPaint();

            // 文字矩阵区域
            Rect textBounds = new Rect();

            // 水印的字体大小
            mPaint.setTextSize(textSize);
            // 文字阴影
//            mPaint.setShadowLayer(0.5f, 0f, 1f, Color.YELLOW);
            // 抗锯齿
            mPaint.setAntiAlias(true);
            // 水印的区域
            mPaint.getTextBounds(markText, 0, markText.length(), textBounds);
            // 水印的颜色
            mPaint.setColor(Color.RED);
            StaticLayout layout = new StaticLayout(markText, 0, markText.length(), mPaint, (int) (w - textSize),
                    Layout.Alignment.ALIGN_NORMAL, 1.0F, 0.5F, true);
            // 文字开始的坐标
            float textX = Utils.dp2px(8) * w / screenWidth;
            // 画文字
            canvas.translate(textX, textX);
            layout.draw(canvas);
        }

        canvas.save(Canvas.ALL_SAVE_FLAG);
        canvas.restore();
        if (!bitmap.isRecycled()) {
            bitmap.recycle();
        }
        return bmpTemp;

    }

}
