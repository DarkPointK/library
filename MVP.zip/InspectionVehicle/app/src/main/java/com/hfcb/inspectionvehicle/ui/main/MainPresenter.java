package com.hfcb.inspectionvehicle.ui.main;

import com.hfcb.inspectionvehicle.base.BasePresenter;
import com.hfcb.inspectionvehicle.dagger.factory.DataManager;
import com.hfcb.inspectionvehicle.dagger.factory.SchedulerProvider;

import javax.inject.Inject;

import io.reactivex.disposables.CompositeDisposable;

public class MainPresenter<V extends MainContract.View> extends BasePresenter<V> implements MainContract.Presenter<V> {

    @Inject
    MainPresenter(DataManager dataManager, SchedulerProvider SchedulerProvider, CompositeDisposable CompositeDisposable) {
        super(dataManager, SchedulerProvider, CompositeDisposable);
    }

    public void inspection() {
        getView().inspection_success(getDataManager().toast());
//        addDisposable(getDataManager().inspection("", new MultipartBody.Builder().build()), new CallBack<Void>() {
//            @Override
//            public void onSuccess(Void data) {
//
//            }
//
//            @Override
//            public void onError(String error) {
//                getView().inspection_fail();
//            }
//        });
    }

}
