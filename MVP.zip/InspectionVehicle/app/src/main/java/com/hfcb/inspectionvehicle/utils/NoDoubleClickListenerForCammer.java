package com.hfcb.inspectionvehicle.utils;

import android.view.View;

public abstract class NoDoubleClickListenerForCammer implements View.OnClickListener {
    // 相机的时间要设置长一点
    private static final long MIN_CLICK_DELAY_TIME = 2000L;
    private long lastClickTime = 0;

    @Override
    public void onClick(View v) {
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastClickTime > MIN_CLICK_DELAY_TIME) {
            lastClickTime = currentTime;
            onNoDoubleClick(v);
        }
    }

    public abstract void onNoDoubleClick(View v);

}
