package com.hfcb.inspectionvehicle.ui.other;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.hfcb.inspectionvehicle.R;
import com.hfcb.inspectionvehicle.base.BaseActivity;

import butterknife.BindView;
import butterknife.ButterKnife;

public class InspectionResultActivity extends BaseActivity {
    @BindView(R.id.tv_license)
    TextView mTvLicense;
    @BindView(R.id.iv_status)
    ImageView mIvStatus;
    @BindView(R.id.tv_status)
    TextView mTvStatus;
    @BindView(R.id.button2)
    Button mButton2;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inspection_result);
        ButterKnife.bind(this);
        mTvLicense.setText(getIntent().getStringExtra("listener"));
        if(getIntent().getBooleanExtra("status",false)){
            mTvStatus.setTextColor(getResources().getColor(R.color.green));
            mTvStatus.setText("允许停放");
        }else{
            mTvStatus.setTextColor(getResources().getColor(R.color.red));
            mTvStatus.setText("禁止停放");
        }
        mButton2.setOnClickListener(v -> finish());
    }
}
