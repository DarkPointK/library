package com.hfcb.inspectionvehicle.base;

public interface IBasePresenter<V extends IBaseView> {

    void onAttach(V mView);

    void onDetach();

}
