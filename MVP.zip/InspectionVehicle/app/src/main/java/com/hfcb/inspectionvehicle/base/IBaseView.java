package com.hfcb.inspectionvehicle.base;

public interface IBaseView {

    void showLoading();

    void hideLoading();

    void openActivityOnTokenExpire();

    void onError(String message);

    void onError(int resId);

    void showMessage(String message);

    boolean isNetworkConnected();

    void hideKeyboard();

}
