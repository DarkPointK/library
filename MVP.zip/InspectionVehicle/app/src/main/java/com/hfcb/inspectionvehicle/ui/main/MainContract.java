package com.hfcb.inspectionvehicle.ui.main;

import com.hfcb.inspectionvehicle.base.IBasePresenter;
import com.hfcb.inspectionvehicle.base.IBaseView;
import com.hfcb.inspectionvehicle.dagger.PerActivity;

public interface MainContract {
    interface View extends IBaseView {
        void inspection_success(String s);

        void inspection_fail();
    }

    @PerActivity
    interface Presenter<V extends View> extends IBasePresenter<V> {

    }
}
