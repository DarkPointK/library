package com.hfcb.inspectionvehicle.dagger.component;

import com.hfcb.inspectionvehicle.MyApplication;
import com.hfcb.inspectionvehicle.dagger.module.ApplicationModule;
import com.hfcb.inspectionvehicle.dagger.factory.DataManager;

import javax.inject.Singleton;

import dagger.Component;

@Singleton
@Component(modules = ApplicationModule.class)
public interface ApplicationComponent {
    void inject(MyApplication application);

    DataManager getDataManager();
}
