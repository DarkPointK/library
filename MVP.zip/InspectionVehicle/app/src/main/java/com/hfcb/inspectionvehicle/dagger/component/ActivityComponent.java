package com.hfcb.inspectionvehicle.dagger.component;

import com.hfcb.inspectionvehicle.dagger.PerActivity;
import com.hfcb.inspectionvehicle.dagger.module.ActivityModule;
import com.hfcb.inspectionvehicle.ui.main.MainActivity;

import dagger.Component;

@PerActivity
@Component(dependencies = ApplicationComponent.class, modules = ActivityModule.class)
public interface ActivityComponent {
    void inject(MainActivity activity);
}
