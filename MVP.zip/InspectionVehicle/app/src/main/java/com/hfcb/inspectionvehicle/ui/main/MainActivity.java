package com.hfcb.inspectionvehicle.ui.main;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.hfcb.inspectionvehicle.MyApplication;
import com.hfcb.inspectionvehicle.R;
import com.hfcb.inspectionvehicle.base.BaseActivity;
import com.hfcb.inspectionvehicle.dagger.component.ActivityComponent;
import com.hfcb.inspectionvehicle.dagger.component.DaggerActivityComponent;
import com.hfcb.inspectionvehicle.dagger.module.ActivityModule;
import com.hfcb.inspectionvehicle.ui.other.InspectionResultActivity;
import com.hfcb.inspectionvehicle.ui.other.TakePictureActivity;
import com.hfcb.inspectionvehicle.utils.PhotoUtils;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

import static com.hfcb.inspectionvehicle.ui.other.TakePictureActivity.REQUEST_CODE;

public class MainActivity extends BaseActivity implements MainContract.View {
    @Inject
    MainPresenter<MainContract.View> mPresenter;
    @Inject
    ActivityComponent mActivityComponent;
    @BindView(R.id.tv_inspectioning)
    TextView mTvInspectioning;
    @BindView(R.id.btn_inspection)
    Button mBtnInspection;
    public static final String PIC_PATH = "1";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        mActivityComponent = DaggerActivityComponent.builder()
                .activityModule(new ActivityModule(this))
                .applicationComponent(((MyApplication) getApplication())
                        .getComponent()).build();
        mActivityComponent.inject(this);
        mPresenter.onAttach(this);
    }

    @Override
    public void inspection_success(String s) {
//        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(MainActivity.this, InspectionResultActivity.class);
        intent.putExtra("listener", "皖A GB716");
        intent.putExtra("status", true);
        startActivityForResult(intent,1);
    }

    @Override
    public void inspection_fail() {
        mTvInspectioning.setText("检验失败");
    }

    @OnClick(R.id.btn_inspection)
    void inspection() {
        TakePictureActivity.startActivityForResult(this);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE && resultCode == RESULT_OK) {
            mTvInspectioning.setVisibility(View.VISIBLE);
            mBtnInspection.setBackgroundColor(getResources().getColor(R.color.red));
            mBtnInspection.setText("重新拍照");
            Bitmap bitmap = BitmapFactory.decodeFile(data.getStringExtra(PIC_PATH));
            if (bitmap == null) {
                inspection_fail();
                return;
            }

            int quality = 70;
            String base64 = PhotoUtils.Bitmap2StrByBase64(bitmap, quality);

            mPresenter.inspection();
        } else {
            mTvInspectioning.setVisibility(View.GONE);
            mBtnInspection.setBackgroundColor(getResources().getColor(R.color.white));
            mBtnInspection.setText("检验车辆");
        }
    }
}
