package com.hfcb.inspectionvehicle.ui.other;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Button;

import com.hfcb.inspectionvehicle.R;
import com.hfcb.inspectionvehicle.base.BaseActivity;
import com.hfcb.inspectionvehicle.ui.main.MainActivity;
import com.hfcb.inspectionvehicle.utils.NoDoubleClickListenerForCammer;
import com.hfcb.inspectionvehicle.utils.PhotoUtils;
import com.wonderkiln.camerakit.CameraKit;
import com.wonderkiln.camerakit.CameraKitError;
import com.wonderkiln.camerakit.CameraKitEvent;
import com.wonderkiln.camerakit.CameraKitEventListener;
import com.wonderkiln.camerakit.CameraKitImage;
import com.wonderkiln.camerakit.CameraKitVideo;
import com.wonderkiln.camerakit.CameraView;

import butterknife.BindView;
import butterknife.ButterKnife;

public class TakePictureActivity extends BaseActivity {
    public static final int REQUEST_CODE = 125;

    public static void startActivityForResult(Activity context) {
        Intent intent = new Intent(context, TakePictureActivity.class);
        context.startActivityForResult(intent, REQUEST_CODE);
    }

    @BindView(R.id.camera)
    CameraView cameraView;
    @BindView(R.id.bt_flash_mode)
    Button btFlash;
    @BindView(R.id.bt_take_pic)
    Button mBtTakePic;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera);
        ButterKnife.bind(this);
        initView();
    }

    protected void initView() {

        btFlash.setOnClickListener(new NoDoubleClickListenerForCammer() {
            @Override
            public void onNoDoubleClick(View v) {
                finish();
            }
        });

        mBtTakePic.setOnClickListener(new NoDoubleClickListenerForCammer() {
            @Override
            public void onNoDoubleClick(View v) {
                if (cameraView != null) {
                    cameraView.captureImage();
                }
            }
        });

        cameraView.addCameraKitListener(new CameraKitEventListener() {
            @Override
            public void onEvent(CameraKitEvent cameraKitEvent) {

            }

            @Override
            public void onError(CameraKitError cameraKitError) {

            }

            @Override
            public void onImage(CameraKitImage cameraKitImage) {
                // 获取bitmap
                Bitmap bitmap = cameraKitImage.getBitmap();
                String savePicPath = PhotoUtils.getPhotoPath(TakePictureActivity.this);
                PhotoUtils.compressAndSaveBitmap(bitmap, savePicPath, 70);
                if (bitmap != null && !bitmap.isRecycled()) {
                    bitmap.recycle();
                }

                Intent intent = new Intent();
                intent.putExtra(MainActivity.PIC_PATH, savePicPath);

                TakePictureActivity.this.setResult(RESULT_OK, intent);
                TakePictureActivity.this.finish();
            }

            @Override
            public void onVideo(CameraKitVideo cameraKitVideo) {

            }
        });
    }

    private void closeFlash() {
        btFlash.setText("打开闪光灯");
        if (cameraView != null)
            cameraView.setFlash(CameraKit.Constants.FLASH_OFF);
    }

    private void openFlash() {
        btFlash.setText("关闭闪光灯");
        if (cameraView != null)
            cameraView.setFlash(CameraKit.Constants.FLASH_TORCH);
    }

    @Override
    protected void onResume() {
        super.onResume();
        cameraView.start();
    }

    @Override
    protected void onPause() {
        cameraView.stop();
        super.onPause();
    }
}
