package com.hfcb.inspectionvehicle.base;

import com.hfcb.inspectionvehicle.dagger.factory.DataManager;
import com.hfcb.inspectionvehicle.dagger.factory.SchedulerProvider;

import javax.inject.Inject;

import io.reactivex.Observable;
import io.reactivex.disposables.CompositeDisposable;

public class BasePresenter<V extends IBaseView> implements IBasePresenter<V> {

    private final DataManager mDataManager;

    private final SchedulerProvider mSchedulerProvider;
    private final CompositeDisposable mCompositeDisposable;

    private V mView;

    @Inject
    public BasePresenter(DataManager dataManager, SchedulerProvider schedulerProvider, CompositeDisposable compositeDisposable) {
        mDataManager = dataManager;
        mSchedulerProvider = schedulerProvider;
        mCompositeDisposable = compositeDisposable;
    }

    @Override
    public void onAttach(V View) {
        mView = View;
    }

    @Override
    public void onDetach() {
        mCompositeDisposable.clear();
        mView = null;
    }

    protected <T> void addDisposable(Observable<T> observable, CallBack<T> callBack) {
        mCompositeDisposable.add(
                observable.subscribeOn(mSchedulerProvider.io()).observeOn(mSchedulerProvider.ui()).subscribe(callBack::onSuccess,
                        throwable -> callBack.onError(throwable.getMessage()))
        );

    }

    public V getView() {
        return mView;
    }

    public DataManager getDataManager() {
        return mDataManager;
    }

    public SchedulerProvider getSchedulerProvider() {
        return mSchedulerProvider;
    }

    public CompositeDisposable getCompositeDisposable() {
        return mCompositeDisposable;
    }
}
