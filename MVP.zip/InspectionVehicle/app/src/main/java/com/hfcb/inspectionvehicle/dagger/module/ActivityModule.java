package com.hfcb.inspectionvehicle.dagger.module;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;

import com.hfcb.inspectionvehicle.dagger.ActivityContext;
import com.hfcb.inspectionvehicle.dagger.factory.AppSchedulerProvider;
import com.hfcb.inspectionvehicle.dagger.factory.SchedulerProvider;

import dagger.Module;
import dagger.Provides;
import io.reactivex.disposables.CompositeDisposable;

@Module
public class ActivityModule {
    private AppCompatActivity mCompatActivity;

    public ActivityModule(AppCompatActivity compatActivity) {
        mCompatActivity = compatActivity;
    }

    @Provides
    @ActivityContext
    Context provideContext() {
        return mCompatActivity;
    }

    @Provides
    AppCompatActivity provideActivity() {
        return mCompatActivity;
    }

    @Provides
    CompositeDisposable provideCompositeDisposable() {
        return new CompositeDisposable();
    }

    @Provides
    SchedulerProvider provideSchedulerProvider() {
        return new AppSchedulerProvider();
    }
}
