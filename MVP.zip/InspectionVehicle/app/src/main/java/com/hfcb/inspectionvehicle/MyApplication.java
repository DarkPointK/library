package com.hfcb.inspectionvehicle;

import android.app.Application;

import com.hfcb.inspectionvehicle.dagger.component.ApplicationComponent;
import com.hfcb.inspectionvehicle.dagger.component.DaggerApplicationComponent;
import com.hfcb.inspectionvehicle.dagger.module.ApplicationModule;

public class MyApplication extends Application {
    private static MyApplication mApplication;
    private ApplicationComponent mApplicationComponent;

    @Override
    public void onCreate() {
        super.onCreate();
        mApplication = this;
        mApplicationComponent = DaggerApplicationComponent.builder()
                .applicationModule(new ApplicationModule(this)).build();
        mApplicationComponent.inject(this);
    }

    public static Application getInstance() {
        return mApplication;
    }

    public ApplicationComponent getComponent() {
        return mApplicationComponent;
    }
}
