package com.hfcb.inspectionvehicle.base;

public interface CallBack<T> {

    void onSuccess(T data);

    void onError(String error);

}
