package com.hfcb.inspectionvehicle.dagger.factory;

import io.reactivex.Observable;
import okhttp3.RequestBody;
import retrofit2.http.Body;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface ApiInterface {
    @POST("")
    Observable<Void> inspection(
            @Query("access_token") String accessToken,
            @Body RequestBody body
    );
}
